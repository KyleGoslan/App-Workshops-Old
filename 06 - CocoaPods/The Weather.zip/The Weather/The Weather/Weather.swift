import Foundation
import SwiftyJSON

class Weather {
    
    var temp: Double!
    var description: String!
    var windSpeed: Double!
    
    init(json: JSON) {
        
        temp = json["main"]["temp"].doubleValue
        description = json["weather"][0]["description"].stringValue
        windSpeed = json["wind"]["speed"].doubleValue
        
    }
    
}