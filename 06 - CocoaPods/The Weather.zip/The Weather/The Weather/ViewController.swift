import UIKit
import CoreLocation
import Alamofire
import SwiftyJSON

class ViewController: UIViewController {
    
    let locationManager = CLLocationManager()

    override func viewDidLoad() {
        super.viewDidLoad()
        
        locationManager.requestWhenInUseAuthorization()
        locationManager.delegate = self
        locationManager.startUpdatingLocation()

    }

}


extension ViewController: CLLocationManagerDelegate {
    
    func locationManager(manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        
        let newLocation = locations.last
        
        if let newLocation = newLocation {
            
            let parameters = [
                "lat": "\(newLocation.coordinate.latitude)",
                "lon": "\(newLocation.coordinate.longitude)",
                "units": "metric",
                "appid": "bc620920461d6ff26e97805183bf8fdd"]
            
            Alamofire.request(.GET, "http://api.openweathermap.org/data/2.5/weather", parameters: parameters)
                .response { request, response, data, error in
                    
                    if let data = data {
                        let json = JSON(data: data)
                        
                        let theWeather = Weather(json: json)
                        print(theWeather.description)
                        print(theWeather.windSpeed)
                        
                    }
                    
                    
                }
            
            
        }
        
        
        
    }
    
}




